package com.example.productOrder.model;
import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;

import java.util.Date;
import java.util.List;

@Entity
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long Id;
    private boolean btn;
    private String name;
    private Integer action;
    private String category;
    private Date date;

    public Customer() {

    }
    public Customer(Long id, boolean btn, String name, Integer action, String category, Date date) {
        Id = id;
        this.btn = btn;
        this.name = name;
        this.action = action;
        this.category = category;
        this.date = date;
    }

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public boolean isBtn() {
        return btn;
    }

    public void setBtn(boolean btn) {
        this.btn = btn;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAction() {
        return action;
    }

    public void setAction(Integer action) {
        this.action = action;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }




    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ProductOrder> productOrders;



    public List<ProductOrder> getOrders() {
        return productOrders;
    }

    public void setOrders(List<ProductOrder> productOrders) {
        this.productOrders = productOrders;
    }


}