package com.example.productOrder.controller;

import com.example.productOrder.model.DataOrder;
import com.example.productOrder.repository.DataOrderRepository;
import com.example.productOrder.repository.DataPointRepository;
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*", methods = {RequestMethod.POST, RequestMethod.GET})
//@RequestMapping("/dataOrders")
public class DataOrderController {
    @Autowired
    private final DataOrderRepository dataOrderRepository;
    @Autowired
    private final DataPointRepository dataPointsRepository;
    private final KieContainer kieContainer;

    @Autowired
    public DataOrderController(DataOrderRepository dataOrderRepository, DataPointRepository dataPointRepository) {
        this.dataOrderRepository = dataOrderRepository;
        this.dataPointsRepository = dataPointRepository;
        KieServices kieServices = KieServices.Factory.get();
        kieContainer = kieServices.getKieClasspathContainer();
    }

    @PostMapping("/dataOrders")
    public ResponseEntity<DataOrder> createDataOrder(@RequestBody Map<String, Object> data) {
        try {
            Long id = (Long) data.get("id");

            Boolean btn = (Boolean) data.get("btn");
            String name = (String) data.get("name");
            Integer action = (Integer) data.get("action");
            String category = (String) data.get("category");
            Boolean value = (Boolean) data.get("value");

            DataOrder dataOrder = new DataOrder(id, btn, name, action, category, value);
            dataOrderRepository.save(dataOrder);


            // Create new Drools session
            KieSession kieSession = createDroolsSession();

            // Inserting Facts into Working Memory
            kieSession.insert(dataOrder);


            // Firing Rules
            kieSession.fireAllRules();

            // Setting the action points based on the rules
            dataOrder.setAction(dataOrder.getAction());

            // Save the updated DataOrder
            dataOrderRepository.save(dataOrder);

            // Disposing Session
            kieSession.dispose();

            // Sending Response to Frontend
            return ResponseEntity.ok(dataOrder);
        } catch(Exception e){
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    private KieSession createDroolsSession() {
        return kieContainer.newKieSession("rulesKSession");
    }
}

