package com.example.productOrder.model;
import jakarta.persistence.*;



import java.util.List;
@Entity
public class DataPoints {
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isValue() {
        return value;
    }

    public void setValue(boolean value) {
        this.value = value;
    }

    public DataPoints() {
    }

    public DataPoints(Integer id, String name, boolean value) {
        this.id = id;
        this.name = name;
        this.value = value;
    }

    @Id
    private long id;
   private String name;
   private boolean value;


//    @OneToOne(mappedBy = "datapoint", cascade = CascadeType.ALL, orphanRemoval = true)
    //private List<DataOrder> dataOrders;



//    public List<DataOrder> getOrders() {
//        return dataOrders;
//    }

//    public void setOrders(List<DataOrder> dataOrders) {
//        this.dataOrders = dataOrders;
//    }





}
