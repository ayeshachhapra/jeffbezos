package com.example.productOrder.repository;


import com.example.productOrder.model.DataPoints;
import org.springframework.data.repository.CrudRepository;

public interface DataPointRepository extends CrudRepository<DataPoints,Long> {
}
