package com.example.productOrder.repository;


import com.example.productOrder.model.DataOrder;
import org.springframework.data.repository.CrudRepository;

public interface DataOrderRepository extends CrudRepository<DataOrder,Long> {
}
