package com.example.productOrder.model;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;

import java.util.Date;
import java.util.List;

@Entity
@Table(name = "data_order")
public class DataOrder {
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public boolean isBtn() {
        return btn;
    }

    public void setBtn(boolean btn) {
        this.btn = btn;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAction() {
        return action;
    }

    public void setAction(Integer action) {
        this.action = action;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public boolean isValue() {
        return value;
    }

    public void setValue(boolean value) {
        this.value = value;
    }

    public DataOrder(long id, boolean btn, String name, Integer action, String category, Boolean value) {
        this.id = id;
        this.btn = btn;
        this.name = name;
        this.action = action;
        this.category = category;
        this.value=value;
    }

    public DataOrder() {
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private boolean btn;
    private String name;
    private Integer action;
    private String category;
    private boolean value;

    @OneToOne()
    @JoinColumn(name = "datapoint_id")
    @JsonManagedReference
    private DataPoints dataPoints;
    @PrePersist
    protected void onCreate() {
        action = 0;
    }
    public DataPoints dataPoints()
    {
        return dataPoints;
    }
    public void setDataPoints(DataPoints dataPoints)
    {
        this.dataPoints=dataPoints;
    }
    public DataPoints getDataPoints()
    {
        return dataPoints;
    }

}
