//package com.example.productOrder.model;
//import jakarta.persistence.*;
//
//
//
//import java.util.List;
//@Entity
//public class DataPoints {
//    public long getId() {
//        return id;
//    }
//
//    public void setId(long id) {
//        this.id = id;
//    }
//
//    public String getName() {
//        return name;
//    }
//
//    public void setName(String name) {
//        this.name = name;
//    }
//
//    public boolean isValue() {
//        return value;
//    }
//
//    public void setValue(boolean value) {
//        this.value = value;
//    }
//
//    public DataPoints() {
//    }
//
//    public DataPoints(Integer id, String name, boolean value) {
//        this.id = id;
//        this.name = name;
//        this.value = value;
//    }
//
//    @Id
//    private long id;
//   private String name;
//   private boolean value;
//
//
//    @OneToOne(mappedBy = "datapoint", cascade = CascadeType.ALL, orphanRemoval = true)
//    private DataOrder dataOrders;
//
//
//
//    public DataOrder getOrders() {
//        return dataOrders;
//    }
//
//    public void setOrders(DataOrder dataOrders) {
//        this.dataOrders = dataOrders;
//    }
//
//
//}
package com.example.productOrder.model;

import jakarta.persistence.*;

@Entity
public class DataPoints {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private boolean value;

    @OneToOne(mappedBy = "dataPoints", cascade = CascadeType.ALL, orphanRemoval = true)
    private DataOrder dataOrder;

    public DataPoints() {
    }

    public DataPoints(String name, boolean value) {
        this.name = name;
        this.value = value;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isValue() {
        return value;
    }

    public void setValue(boolean value) {
        this.value = value;
    }

    public DataOrder getDataOrder() {
        return dataOrder;
    }

    public void setDataOrder(DataOrder dataOrder) {
        this.dataOrder = dataOrder;
    }
}
